// header files
#include <iostream>
#include <cstdlib>
#include "Stack.h"


using namespace std;

// stack stay implementation
template <typename T>
Stack<T>::Stack(int a )
 {
cout << "in stack constructor" << endl;
   data = new T[a];
   max = a;
   top = -1;
   actual = 0;
 }

template <typename T>
Stack<T>::Stack( const Stack& a )
 {
cout << "in stack copy const" << endl;
   data = new T[a.max];
   for( int i = 0; i < a.actual; i++ )
    {
      data[i] = a.data[i];
    }
   max = a.max;
   top = a.top;
   actual = a.actual;
 }

template <typename T>
Stack<T>::~Stack()
 {
cout << "in stack deconstructor" << endl;
   delete[]data;
   max = 0;
   top = -1;
   actual = 0;
   data = NULL;
 }

template <typename T>
Stack<T>& Stack<T>::operator=( const Stack& a )
 {
cout << "in = stack" << endl;
   for( int i = 0; i < a.actual; i++ )
    {
      data[i] = a.data[i];
    }
   max = a.max;
   top = a.top;
   actual = a.actual;
   
   return *this;
 }

template <typename T>
bool Stack<T>::push(T a)
 {
cout << "in stack push" << endl;
   bool isGood = false;
   int actCounter = actual;

   if( full() == false )
    {
      for( int i = 0; i < actual; i++ )
       {
         data[actCounter]=data[actCounter-1];
         actCounter--;
       }

      if( top < 0 )
        top++;

      data[top] = a;

      actual++;

      isGood = true;
    }

   return isGood;
 }

template <typename T>
bool Stack<T>::pop( T& a ) 
 {
cout << "in stack pop" << endl;
   bool isGood = false;
   int topCounter=0;

   if( empty() == false )
    {
      a = data[top];

      for( int i = 0; i < actual-1; i++ )
       {
         data[topCounter] = data[topCounter+1];
         topCounter++;
       }
      actual--;

      if( actual == 0 )
       top--;

      isGood = true;
    }

   return isGood;
 }

template <typename T>
bool Stack<T>::empty() const
 {
cout << "in stack empty" << endl;
   bool isEmpty = false;

   if( actual == 0 )
     isEmpty = true;

   return isEmpty;
 }

template <typename T>
bool Stack<T>::full()const
 {
cout << "in stack full" << endl;
   bool isFull = false;

   if( actual == max )
     isFull = true;

   return isFull;
 }

template <typename T>
bool Stack<T>::clear()  // why is this bool?
 {
cout << "in stack clear" << endl;
   bool isClear = false;

   if( top == -1 && actual == 0 )
     return isClear;

   top = -1;
   actual = 0;
   isClear = true;

   return isClear;
 }

template <typename T>
void Stack<T>::print()const
 {
cout << "in stack print" << endl;
   for( int i = 0; i < actual; i++ )
    {
     if( i == 0 )
      {
        cout << '[' << data[i] << ']' << endl;
      } 
     else
        cout << data[i] << endl;
    }
 }


