// header files
#include <iostream>
#include <cstdlib>
#include "Queue.h"

using namespace std;

// implementation stay queue
Queue::Queue( int a )
 {
   data = new int[a];
   max = a;
   front = -1;
   rear = -1;
 }

Queue::Queue( const Queue& a )
 {
   data = new int[a.max];
   max = a.max;
   front = a.front;
   rear = a.rear;
   for( int i = 0; i < rear+1; i++ )
    {
      data[i] = a.data[i];
    }
 }

Queue::~Queue()
 {
   delete[]data;
   max = 0;
   front = rear = -1;
   data =  NULL;
 }

Queue& Queue::operator=(const Queue& a )
 {
   max = a.max;
   front = a.front;
   rear = a.rear;

   for( int i = 0; i < rear+1; i++ )
    {
      data[i] = a.data[i];
    }

   return *this;
 }

bool Queue::enqueue(int a )
 {
   bool isGood = false;

   if( full() == false )
    {
      if( front == -1 )
        front++;

      rear++;
      data[rear] = a;
      isGood = true;
    }

   return isGood;
 }

bool Queue::dequeue( int& a )
 {
   bool isGood = false;

   if( empty() == false )
    {
      a = data[front];
      for( int i = 0; i < rear; i++ )
       {
         data[i] = data[i+1];
       }
      rear--;
      if(rear == -1 )
        front--;
      isGood = true;
    }

   return isGood;
 }

bool Queue::empty()const
 {
   bool isEmpty;

   if( front == rear == -1 )
     isEmpty = true;

   return isEmpty;
 }

bool Queue::full()const
 {
   bool isFull = false;

   if( rear == max - 1 )
     isFull = true;

   return isFull;
 }

bool Queue::clear() // is this proper usage?
 {
   bool isClear = false;

   if( front != -1 && rear != -1 )
    {
      front = -1;
      rear = -1;
      isClear = true;
    }

   return isClear;
 }

bool Queue::operator==(const Queue& a) const
 {
   bool isSame = false;

   if( a.front == front && a.rear == rear && a.max == max )
     isSame = true;

   for( int i = 0; i < rear+1; i++ )
    {
      if( data[i] != a.data[i] )
        isSame = false;
    }

   return isSame;
 }

ostream& operator<<(ostream& output, const Queue& a )
 {
   output << "Front: " << a.front << endl << "Rear: " << a.rear
          << endl << "Max: " << a.max << endl;

   for( int i = 0; i < a.rear+1; i++ )
    {
      if( i == 0 )
       {
         output << '{' << a.data[i] << '}' << endl;
       }

      if( i == a.rear )
       {
         output << '|' << a.data[i] << '|' << endl;
       }

      else
         output << a.data[i] << endl;
    }

   return output;
 }






