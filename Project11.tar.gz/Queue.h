#ifndef __QUEUE_H_
#define __QUEUE_H_
#include <iostream>

using namespace std;

template <typename T>
class Queue;

template <typename T>
class QNode{
	private:
		QNode( T, QNode* = NULL );
		T data;
		QNode* next;
		friend class Queue<T>;
          };

template <typename T>
class Queue{
        public:
                Queue(int = 0);
                Queue(const Queue&);
                ~Queue();
                Queue& operator=(const Queue&);
                bool enqueue(T);
                bool dequeue(T&);
                bool empty() const;
                bool full() const;
                bool clear();
                bool operator==(const Queue&) const;
		void print()const;

        private:
                QNode<T>* front;
                QNode<T>* rear;
};

#endif


