// header files
#include <iostream>
#include <cstdlib>
#include "Queue.h"

using namespace std;

// implementation wrap queue
Queue::Queue( int a )
 {
   data = new int[a];
   max = a;
   front = -1;
   rear = -1;
 }

Queue::Queue( const Queue& a )
 {
   int frontCopy = a.front;

   data = new int[a.max];
   for( int i = 0; i < (a.rear%a.max - a.front%a.max)+1; i++ )
    {
      data[frontCopy%a.max] = a.data[frontCopy%a.max];
      frontCopy++;
    }
   max = a.max;
   front = a.front;
   rear = a.rear;
 }

Queue::~Queue()
 {
   delete[]data;
   data = NULL;
   front = rear = -1;
   max = 0;
 }

Queue& Queue::operator=(const Queue& a )
 {
   int frontCopy = a.front;

   front = a.front;
   rear = a.rear;
   max = a.max;
   for( int i = 0; i < rear%max - front%max +1; i++ )
    {
      data[frontCopy%max] = a.data[frontCopy%max];
      frontCopy++;
    }

   return *this;
 }

bool Queue::enqueue(int a )
 {
   bool isGood = false;

   if( full() == false )
    {
      rear++;
      if(front == -1 )
        front++;
      data[rear%max] = a;

      isGood = true;
    }

   return isGood;
 }

bool Queue::dequeue( int& a )
 {
   bool isGood = false;

   if( empty() == false )
    {
      a = data[front%max];

      if( front == rear )
       {
         front = rear = -1;
       }
      else
         front++;

      isGood = true;
    }

   return isGood;
 }

bool Queue::empty()const
 {
   bool isEmpty = false;

   if( front == -1 && rear == -1 )
     isEmpty = true;
   
   return isEmpty;
 }

bool Queue::full()const
 {
   bool isFull = false;

   if( front%max -1 == rear%max || 
     ( rear%max == max && front%max == 0 ) )
    {
      isFull = true;
    }

   return isFull;
 }

bool Queue::clear()
 {
   bool isClear = false;

   if( rear!= -1 && front != -1 )
    {
      rear = front = -1;
      isClear = true;
    }

   return isClear;
 }

bool Queue::operator==(const Queue& a) const
 {
   bool isSame = false;
   int frontCopy = front;

   if( max == a.max && rear == a.rear && front == a.front )
     isSame = true;

   for( int i = 0; i < rear%max - front%max +1; i++ )
    {
      if( data[frontCopy%max] != a.data[frontCopy%max])
        isSame = false;
      frontCopy++;
    }

   return isSame;
 }

ostream& operator<<(ostream& output, const Queue& a )
 {
   int copyFront = a.front;

   output << "Front: " << a.front << endl << "Rear: " << a.rear 
          << endl << "Max: " << a.max << endl;
   if( a.rear == -1 && a.front == -1 )
     return output;

   for( int i = 0; i < a.rear-a.front+1; i++)
    {
      if( i == 0 )
        cout << '{' << a.data[copyFront%a.max] << '}' << endl;

      if( i == a.rear-a.front )
        cout << '|' << a.data[copyFront%a.max] << '|' << endl;

      else
         output << a.data[copyFront%a.max] << endl;

      copyFront++;
    }

   return output;
 }









