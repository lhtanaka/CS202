// header files
#include <iostream>
#include <cstdlib>
#include "Stack.h"


using namespace std;

// stack top implementation
template <typename T>
Stack<T>::Stack(int a )
 {
   data = new T[a];
   max = a;
   top = -1;
 }

template <typename T>
Stack<T>::Stack( const Stack& a )
 {
   data = new T[a.max];
   max = a.max;
   top = a.top;
   for( int i = 0; i < top; i++ )
    {
      data[i] = a.data[i];
    }
 }

template <typename T>
Stack<T>::~Stack()
 {
cout << "dallocation" << endl;
   delete[] data;
   max = 0;
   top = -1;
   data = NULL;
 }

template <typename T>
Stack<T>& Stack<T>::operator=( const Stack& a )
 {
   if( max == a.max )
    {
      for( int i = 0; i < a.top; i++ )
       {
         data[i] = a.data[i];
       }
      max= a.max;
      top = a.top;

    }

   return *this;
 }

template <typename T>
bool Stack<T>::push(T a)
 {
   bool isGood = false; 

   if( full() == false )
    {
      top++;
      data[top] = a;
      isGood = true;
    }

   return isGood;
 }

template <typename T>
bool Stack<T>::pop( T& a )
 {
   bool isGood=false;

   if( empty() == false )
    {
      a = data[top];
      top--;
      isGood = true;
    }

   return isGood;
 }

template <typename T>
bool Stack<T>::empty() const
 {
   bool isEmpty = false;

   if( top == -1 )
    isEmpty = true;

   return isEmpty;
 }

template <typename T>
bool Stack<T>::full()const
 {
   bool isFull = false;

   if( top == max )
     isFull = true;

   return isFull;
 }

template <typename T>
bool Stack<T>::clear()
 {
   bool isClear = false;

   if( top = -1 )
     return isClear;

   top = -1;
   isClear = true;

   return isClear;
 }

template <typename T>
void Stack<T>::print()const
 {
   for( int i = 0; i < top; i++ )
    {
      if( i == 0)
        cout << '[' << data[i] << ']' << endl;

      else
        cout << data[i] << endl;
    }
 }








