#include <iostream>
#include <cstdlib>
#include "Queue.h"

using namespace std;

// node implementation
template <typename T>
QNode<T>::QNode( T a, QNode* nptr )
 {
cout << "in qnode constructor" << endl;
   data = a;
   next = nptr;
 }

// queue node based queue implementation
template <typename T>
Queue<T>::Queue( int a )
 {
cout << "In queue constructor" << endl;
   front = NULL;
   rear = NULL;
 }

template <typename T>
Queue<T>::Queue(const Queue& a )
 {
cout << "in queue copy constructor" << endl;
   QNode<T>* temp = a.front;
   QNode<T>* temp2;

   front = new QNode<T> ( a.front->data, NULL );
   temp = temp->next;
   temp2 = front;

   while( temp != NULL )
    {
      rear = new QNode<T> ( temp->data, NULL );
      temp2->next = rear;
      temp = temp->next;
      temp2 = rear;
    }   
 }

template <typename T>
Queue<T>::~Queue()
 {
cout << "in queue destructor" << endl;
   QNode<T>* temp = front;
   
   while( temp != NULL )
    {
cout << "break1" << endl;
      front = front->next;
cout << front->data << endl;
cout << "break2" << endl;
      delete temp;
cout << "break3" << endl;
      temp = front;
cout << "break4" << endl;
    }
   front = temp = rear = NULL;
 }

template <typename T>
Queue<T>& Queue<T>::operator=(const Queue& a )
 {
cout << "In = operator" << endl;
   bool success;
   QNode<T>* temp = a.front;
   QNode<T>* temp2;

   success = clear();
   front = new QNode<T> (a.front->data, NULL );
   temp2 = front;

   while( temp != NULL )
    {
      temp = temp->next;
      rear = new QNode<T> ( temp->data, NULL );
      temp2->next = rear;
      temp2 = rear;
    }

   return *this;
 }

template <typename T>
bool Queue<T>::enqueue(T a )
 {
cout << "In enqueue" << endl;
   bool isGood = false;
   QNode<T>* temp;

   if( !full() )
    {
      if( empty() )
       {
         front = new QNode<T> ( a, NULL );
         rear = front;
       }
      else
       {
         temp = rear;
         rear = new QNode<T>( a, NULL );
         temp->next = rear;
       }
      isGood = true;
    }
   return isGood;
 }

template <typename T>
bool Queue<T>::dequeue( T& a )
 {
cout << "in dequeue" << endl;
   bool isGood = false;
   QNode<T>* temp = front;

   if( !empty() )
    {
      if( front == rear )
        rear = NULL;
      a = front->data;
      front = front->next;
      delete temp;
      isGood = true;
    }
   temp = NULL;

   return isGood;
 }

template <typename T>
bool Queue<T>::empty()const
 {
cout << "in queue Empty" << endl;
   bool isEmpty = false;

   if( front == NULL && rear == NULL )
     isEmpty = true;

   return isEmpty;
 }

template <typename T>
bool Queue<T>::full()const
 {
cout << "In queue full" << endl;
   bool isFull = false;

   //should I include if it's above52 it's full???

   return isFull;
 }

template <typename T>
bool Queue<T>::clear()
 {
cout << "In queueu clear" << endl;
   bool isGood;

   return isGood;
 }

template <typename T>
bool Queue<T>::operator==(const Queue& a )const
 {
cout << "in == queue" << endl;
   bool isGood = true, repeat = false;
   QNode<T>* temp = front;
   QNode<T>* temp2 = a.front;

   if( temp->data == temp2->data )
     repeat = true;

   while( repeat )
    {
      if( temp->data != temp2->data )
        return false;

      temp = temp->next;
      temp2 = temp2->next;

      if( temp2 == NULL || temp == NULL )
        repeat = false;
    }

   if( temp != NULL && temp!= NULL )
     isGood = false;

   return isGood;
 }


template <typename T>
void Queue<T>::print()const
 {
cout << "in queue print" << endl;
   QNode<T>* temp = front;
   while( temp != NULL )
    {
      cout << temp->data;
      temp = temp->next;
    }
 }








