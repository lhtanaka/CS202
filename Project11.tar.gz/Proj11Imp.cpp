// header files
#include <iostream>
#include <fstream>
#include "Proj11Header.h"

using namespace std;

// card implemntation
card::card()
 {
   rank = 0;
   suit = "suit";
   location = "location";
 }

card::card(int a, string b, string c )
 {
   rank = a;
   suit = b;
   location = c;
 }

card::card(const card& a )
 {
   rank = a.rank;
   suit = a.suit;
   location = a.location;
 }

card::~card()
 {
   rank = 0;
   suit = "0";
   location = "0";
 }

void card::setLoc( const string a )
 {
   location = a;
 }

int card::getRank()const
 {
   return rank;
 }

string card::getSuit()const
 {
   return suit;
 }

string card::getLoc()const
 {
   return location;
 }

bool card::operator<(const card& a)
 {
   bool isSame = false;

   if( rank < a.rank && suit < a.suit )
      isSame = true;

   return isSame;
 }

card& card::operator=(const card& a)
 {
   rank = a.rank;
   suit = a.suit;
   location = a.location;

   return *this;
 }

bool operator>(const card& a, const card& b )
 {
   bool isSame = false;

   if( a.rank > b.rank && a.suit > b.suit )
     isSame = true;

   return isSame;
 }

ostream& operator<<(ostream& output, const card& a)
 {
   output << a.rank << ' ' << a.suit << ' ' << a.location << endl;
   return output;
 }

ifstream& operator>>(ifstream& input, card& a )
 {
   
   input >> a.suit >> a.rank;
   return input;
 }


// player implementation
player::player()
 {
   name = "name";
   id = new int[5];
   for( int i = 0; i < 5; i++ )
    {
      id[i]=0;
    }
   hand = new card[5];
 }

player::player(const player& a)
 {
   name = a.name;
   id = new int[5];
   for( int i = 0; i <5; i++ )
    {
      id[i] = a.id[i];
    }
   hand = new card[5];
   for( int j = 0; j<5; j++ )
    {
      hand[j] = a.hand[j];
    }
 }

player::~player()
 {
   name = "0";
   delete[]id;
   delete[]hand;
 }

void player::setId( const int* a )
 {
   for( int i =0; i < 5; i++ )
    {
      id[i]=a[i];
    }
 }

void player::setHand( card* a, const int numPlayers, const int counter )
 {
   for( int i =0; i < 5; i++ )
    {
      hand[i]=a[(numPlayers*i)+counter];
      hand[i].setLoc(name); 
      a[(numPlayers*i)+counter].setLoc(name);
   
    }
 }

string player::getName()const
 {
   return name;
 }

int* player::getId()const
 {
   return id;
 }

card* player::getHand()const
 {
   return hand;
 }

ostream& operator<<(ostream& output, const player& playA )
 {
   output << playA.name << ' ';

   for( int i = 0; i < 5; i++ )
     output << playA.id[i];
   cout << endl;
cout << "MOOOOOOO" << endl;
   for( int j = 0; j < 5; j++ )
    {
      output << playA.hand[j];
    }
   cout << endl;

   return output;
 }

ifstream& operator>>(ifstream& input, player& playA )
 {
   char dummy;
   input >> playA.name;

   for( int i = 0; i < 5; i++ )
    {
      input >> dummy;
      playA.id[i] = dummy-'0';
    }

   return input;
 }
