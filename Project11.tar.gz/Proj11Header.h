// header file for Proj 8
#include <iostream>
#include <fstream>

using namespace std;

// card class
class card{
    public:
	card();
	card( int, string, string );
	card( const card & );
	~card();
	void setLoc( const string );
	int getRank()const;
	string getSuit()const;
	string getLoc()const;
	bool operator<(const card& );
	card& operator=(const card& );
	friend bool operator>(const card&, const card& );
	friend ostream& operator<<(ostream&, const card& );
	friend ifstream& operator>>(ifstream&, card& );
    private:
	int rank;
	string suit;
	string location;
    };

//player class
class player{
    public:
	player();
	player( const player& );
	~player();
	void setId( const int* );
	void setHand( card*, const int, const int );
	string getName()const;
	int* getId()const;
	card* getHand()const;
	friend ostream& operator<<(ostream&, const player& );
	friend ifstream& operator>>(ifstream&, player& );
    private:
	string name;
	int* id;
	card* hand;
    };

