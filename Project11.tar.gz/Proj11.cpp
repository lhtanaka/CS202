// header files
#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include "dataStruct.cpp"


using namespace std;

// global constants
const int numCards = 52;

// function prototypes
void shuffleCards( Queue<card>, List& );

void displayUnshuffledCards( Queue<card> );

void displayShuffledCards( List );

void displayPlayerInfo( Queue<player> );

void dealCards( Queue<player>&, List, int numOfPlayers, Stack<card>& );//player* pptr, int numOfPlayers, card* shuf_cptr );

void dealToStock( Stack<card>&, Stack<card>&, int numOfPlayers );//card* shuf_cptr, card* stock_cptr, int numOfPlayers );

void dealToDiscard( Stack<card>&, Stack<card>&, int numOfPlayers );//card* shuf_cptr, card* disc_cptr );

// main function
int main()
   {
    // initialize program and variables
    ifstream fin;
    string deckFile;
    string playerFile;
    int numOfPlayers;
    bool isQuit = false;
    bool success = false;
    char userSelection;
    card tempCard;
    player tempPlayer;

    // get input files and num of players
    cout << "Please enter card file name: ";
    cin >> deckFile;
    cout << endl << "Please enter player file name: ";
    cin >> playerFile;

    do
     {
       cout << endl << "Please enter the number of players (2-8): ";
       cin >> numOfPlayers;
       cout << endl << endl;
     }
    while( numOfPlayers < 2 || numOfPlayers > 8 );

       //declare card data structures
       List fullShuf;
       Queue<card> unshuf;
       Stack<card> stock;
       Stack<card> discard;
       Stack<card> rdyToDeal;

       // declare player array and initialize
       Queue<player> playQ;

       // get inputs for deck
       fin.clear();
       fin.open(deckFile.c_str() );

       for( int i = 0; i < numCards; i++ )
        {
          fin >> tempCard;
          tempCard.setLoc("Unshuffled");
          unshuf.enqueue( tempCard );
        }

       fin.close();

unshuf.print();

       // get inputs for players
       fin.clear();
       fin.open( playerFile.c_str() );

       for( int j = 0; j < numOfPlayers; j++ )
        {
          fin >> tempPlayer;
cout << tempPlayer;
          playQ.enqueue( tempPlayer );
        }
playQ.print();
       fin.close();

    // display menu and prompt user
    do
     {
       cout << "Menu:" << endl << "=========" << endl
            << "1. <S>huffle Cards" << endl 
            << "2. <D>isplay Unshuffled Cards" << endl
            << "3. Display Sh<U>ffled Cards" << endl
            << "4. Dea<L> Cards to Stock and Discard" << endl
            << "5. Display <P>layer Info" << endl
            << "6. <Q>uit" << endl << endl;
       cout<< "Please select option: ";
       cin >> userSelection;

       // switch options for menu
       switch( userSelection )
        {
          // shuffle cards
          case '1':
          case 'S':
          case 's':


          shuffleCards( unshuf, fullShuf );
cout << fullShuf;
          break;

          // display unshuffled cards
          case '2':
          case 'D':
          case 'd':

          displayUnshuffledCards( unshuf );

          break;

          // display shuffled cards
          case '3':
          case 'U':
          case 'u':

         displayShuffledCards( fullShuf );
cout << fullShuf;
          break;

          // deal the cards
          case '4':
          case 'L':
          case 'l':
          dealCards( playQ, fullShuf, numOfPlayers, rdyToDeal );//pptr, numOfPlayers, shuf_cptr );
	  dealToStock( rdyToDeal, stock, numOfPlayers ); //shuf_cptr, stock_cptr, numOfPlayers);
          dealToDiscard( rdyToDeal, discard, numOfPlayers ); //shuf_cptr, disc_cptr );


          break;

          // show player info
          case '5':
          case 'P':
          case 'p':

         displayPlayerInfo( playQ );
stock.print();
cout << "discard" << endl;
discard.print();
          break; 

          // quit program
          case '6':
          case 'Q':
          case 'q':

          isQuit = true;

          break;

          // invalid input option
          default:
          break;
        }
     }
    while( isQuit == false );

    // de-allocate dynamic memory

    return 0;
   }



// supporting function implementations
void shuffleCards( Queue<card> unshuf, List& shuf )
 {
   // initialize variables

   card temp, temp2;

   // clear list
   shuf.clear();

   // move to list from queue
   for( int r = 0; r < numCards; r++)
    {
      unshuf.dequeue(temp);
      unshuf.enqueue(temp);
      temp.setLoc("Shuffled");
      shuf.insertAfter( temp );
    }

   // create random array
   int* iptr = new int[52];
   int randInt, copyInt;
   srand(time(NULL));

   // set int array
   for( int i = 0; i < numCards; i++ )
    {
      iptr[i] = i;
    }
   // randomize int array
   for( int j = 0; j < numCards; j++ )
    {
      randInt = rand() % 52;
      copyInt = iptr[j];
      iptr[j] = iptr[randInt];
      iptr[randInt] = copyInt;
    }

   // shuffle in the list
   for( int h = 0; h< numCards; h++ )
    {
      shuf.gotoBeginning();
      shuf.getCursor( temp );      
      for( int e = 0; e< iptr[h]; e++ )
       {
         shuf.gotoNext();
       }
      shuf.getCursor( temp2 );
      shuf.replace( temp );
      shuf.gotoBeginning();
      shuf.replace(temp2);
    }
//cout << shuf << endl;
 }

void displayUnshuffledCards( Queue<card> unshuf )
 {
   unshuf.print();
 }

void displayShuffledCards( List shuf )
 {
   shuf.gotoBeginning();
   cout << shuf << endl;
 }

void displayPlayerInfo( Queue<player> playQ )//player* pptr, int numOfPlayers )
 {
   playQ.print();
/*
   for( int i = 0; i < numOfPlayers; i ++ )
    {
      cout << pptr[i];
    }
*/
 }

void dealCards( Queue<player>& playQ, List shuf, int numOfPlayers, Stack<card>& shuffled )//player* pptr, int numOfPlayers, card* shuf_cptr )
 {
   card temp;
   player tempP;
   int counter = 0;

   shuf.gotoBeginning();
   // move to stack to deal
   for( int g = 0; g< numCards-1; g++ ) // MAKE SURE TO GET RID OF THIS -1*************************************************************** *****************************
    {
//      shuf.gotoBeginning();
      shuf.remove( temp );
cout << "BREAK1 " << temp << endl;
      shuffled.push( temp );
//shuffled.print();
    }
shuffled.print();
/*
   // deal to players
   for( int i = 0; i < 5; i++ )
    {
      for( int j = 0; j< numOfPlayers; j++ )
       {
         playQ.dequeue(tempP);
         tempP.setHand( shuffled, numOfPlayers, counter );
         playQ.enqueue(tempP);
       }
      counter++;
    }

/*
   int counter=0;

   //deal to players
   for(int i =0; i < numOfPlayers; i++ )
    {
      pptr[i].setHand( shuf_cptr, numOfPlayers, counter );
      counter++; //shuf_cptr++;
    }
*/
 }

void dealToStock( Stack<card>& shuf, Stack<card>& stock, int numOfPlayers )//card* shuf_cptr, card* stock_cptr, int numOfPlayers )
 {
   card temp;
   for( int i = 0; i < numCards - numOfPlayers*5; i++ )
    {
      shuf.pop(temp);
      temp.setLoc("Stock");
      stock.push(temp);
    }
/*
   for( int i = 0; i < numCards - numOfPlayers*5; i++ )
    {
      stock_cptr[i] = shuf_cptr[i+numOfPlayers*5];
      stock_cptr[i].setLoc( "Stock" );
      shuf_cptr[i+numOfPlayers*5].setLoc( "Stock" );
    }
*/
 }

void dealToDiscard( Stack<card>& shuf, Stack<card>& discard, int numOfPlayers )//card* shuf_cptr, card* disc_cptr )
 {
   card temp;

   shuf.pop(temp);
   temp.setLoc("Discard");
   discard.push(temp);
/*
   disc_cptr[0]=shuf_cptr[numCards-1];
   disc_cptr[0].setLoc( "Discard" );
   shuf_cptr[numCards-1].setLoc( "Discard" );
*/
 }






















