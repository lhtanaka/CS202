// header files
#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include "dataStruct.cpp"

using namespace std;

ifstream fin;

const int numCards = 52;
// test portion

int main()
 {
    // initialize program and variables
    ifstream fin;
    string deckFile;
    string playerFile;
    int numOfPlayers;
    bool isQuit = false;
    bool success = false;
    char userSelection;
    card tempCard;
    player tempPlayer;

    // get input files and num of players
    cout << "Please enter card file name: ";
    cin >> deckFile;
    cout << endl << "Please enter player file name: ";
    cin >> playerFile;

    do
     {
       cout << endl << "Please enter the number of players (2-8): ";
       cin >> numOfPlayers;
       cout << endl << endl;
     }
    while( numOfPlayers < 2 || numOfPlayers > 8 );

       //declare card data structures

       // declare player array and initialize
       Queue<player> playQ;

       // get inputs for players
       fin.clear();
       fin.open( playerFile.c_str() );

       for( int j = 0; j < numOfPlayers; j++ )
        {
          fin >> tempPlayer;
          playQ.enqueue( tempPlayer );
        }
cout << "break1" << endl;

playQ.print();

cout << "break2" << endl;
       fin.close();


   return 0;
 }
