// header files 
#include <iostream>
#include <cstdlib>
#include "dataStruct.h"
#include <fstream>

using namespace std;

// card implemntation
card::card()
 {
   rank = 0;
   suit = "suit";
   location = "location";
 }

card::card(int a, string b, string c )
 {
   rank = a;
   suit = b;
   location = c;
 }

card::card(const card& a )
 {
   rank = a.rank;
   suit = a.suit;
   location = a.location;
 }

card::~card()
 {
   rank = 0;
   suit = "0";
   location = "0";
 }

void card::setLoc( const string a )
 {
   location = a;
 }

int card::getRank()const
 {
   return rank;
 }

string card::getSuit()const
 {
   return suit;
 }

string card::getLoc()const
 {
   return location;
 }

bool card::operator<(const card& a)
 {
   bool isSame = false;

   if( rank < a.rank && suit < a.suit )
      isSame = true;

   return isSame;
 }

card& card::operator=(const card& a)
 {
   rank = a.rank;
   suit = a.suit;
   location = a.location;

   return *this;
 }

bool card::operator==(const card& a )
 {
   bool isSame = false;

   if( rank == a.rank && suit == a.suit )
     isSame = true;

   return isSame;
 }

bool operator>(const card& a, const card& b )
 {
   bool isSame = false;

   if( a.rank > b.rank && a.suit > b.suit )
     isSame = true;

   return isSame;
 }

ostream& operator<<(ostream& output, const card& a)
 {
   output << a.rank << ' ' << a.suit << ' ' << a.location << endl;
   return output;
 }

ifstream& operator>>(ifstream& input, card& a )
 {
   
   input >> a.suit >> a.rank;
   return input;
 }


// player implementation
player::player()
 {
   name = "name";
   id = new int[5];
   for( int i = 0; i < 5; i++ )
    {
      id[i]=0;
    }
   hand = new card[5];
 }

player::player(const player& a)
 {
   card temp;
   name = a.name;
   id = new int[5];
   for( int i = 0; i <5; i++ )
    {
      id[i] = a.id[i];
    }
   hand = new card[5];
   
   for( int j = 0; j<5; j++ )
    {
      hand[j] = a.hand[j];
    }

 }

player::~player()
 {
   name = "0";
   delete[]id;
   delete[]hand;
 }

void player::setId( const int* a )
 {
   for( int i =0; i < 5; i++ )
    {
      id[i]=a[i];
    }
 }

void player::setHand( Stack<card>& a, const int numPlayers, const int counter )
 {
   card temp;

   a.pop( temp );
   temp.setLoc( name );
   hand[counter] = temp;
/*
   for( int i =0; i < 5; i++ )
    {
      hand[i] = 
/*
      hand[i]=a[(numPlayers*i)+counter];
      hand[i].setLoc(name); 
      a[(numPlayers*i)+counter].setLoc(name);
  */ 
    //}
 }

string player::getName()const
 {
   return name;
 }

int* player::getId()const
 {
   return id;
 }

card* player::getHand()const
 {
   return hand;
 }

ostream& operator<<(ostream& output, const player& playA )
 {
   output << playA.name << ' ';

   for( int i = 0; i < 5; i++ )
     output << playA.id[i];
   cout << endl;

   for( int j = 0; j < 5; j++ )
    {
      output << playA.hand[j];
    }
   cout << endl;

   return output;
 }

ifstream& operator>>(ifstream& input, player& playA )
 {
   char dummy;
   input >> playA.name;

   for( int i = 0; i < 5; i++ )
    {
      input >> dummy;
      playA.id[i] = dummy-'0';
    }

   return input;
 }

player& player::operator=(const player& a )
 {
   name = a.name;
   for( int i = 0; i < 5; i++ )
    {
      id[i] = a.id[i];
      hand[i] = a.hand[i];
    }
   return *this;
 }

bool player::operator==(const player& a )
 {
   bool isSame = true;

   if( !(name == name) )
     return false;

   for( int i = 0; i < 5; i++ )
    {
      if( !(id[i]==a.id[i]))
        return false;
      if( !(hand[i]==a.hand[i]))
        return false;
    }

   return isSame;;
 }

// node implementation
template <typename T>
QNode<T>::QNode( T a, QNode<T>* nptr )
 {
cout << "in qnode constructor" << endl;
   data = a;
   next = nptr;
 }

// queue node based queue implementation
template <typename T>
Queue<T>::Queue( int a )
 {
cout << "In queue constructor" << endl;
   front = NULL;
   rear = NULL;
 }

template <typename T>
Queue<T>::Queue(const Queue& a )
 {
int counter = 0;
cout << "in queue copy constructor" << endl;
   QNode<T>* temp = a.front;
   QNode<T>* temp2;

   front = new QNode<T> ( a.front->data, NULL );
   temp = temp->next;
   temp2 = front;

   while( temp != NULL )
    {
cout << counter << endl;
counter++;
      rear = new QNode<T> ( temp->data, NULL );
      temp2->next = rear;
      temp = temp->next;
      temp2 = rear;
    }   
 }

template <typename T>
Queue<T>::~Queue()
 {
cout << "in queue destructor" << endl;
   if(!empty() )
    {
      QNode<T>* temp = front;
   
      while( temp != NULL )
       {
         front = front->next;
         delete temp;
         temp = front;
       }
      front = temp = rear = NULL;
    }
 }

template <typename T>
Queue<T>& Queue<T>::operator=(const Queue& a )
 {
cout << "In = operator" << endl;
   bool success;
   QNode<T>* temp = a.front;
   QNode<T>* temp2;

   success = clear();
   front = new QNode<T> (a.front->data, NULL );
   temp2 = front;

   while( temp != NULL )
    {
      temp = temp->next;
      rear = new QNode<T> ( temp->data, NULL );
      temp2->next = rear;
      temp2 = rear;
    }

   return *this;
 }

template <typename T>
bool Queue<T>::enqueue(T a )
 {
cout << "In enqueue" << endl;
   bool isGood = false;
   QNode<T>* temp;

   if( !full() )
    {
      if( empty() )
       {
         front = new QNode<T> ( a, NULL );
         rear = front;
       }
      else
       {
         rear->next = new QNode<T>( a, NULL );

         rear = rear->next;
       }
      isGood = true;
    }
   return isGood;
 }

template <typename T>
bool Queue<T>::dequeue( T& a )
 {
cout << "in dequeue" << endl;
   bool isGood = false;
   QNode<T>* temp = front;

   if( !empty() )
    {
      if( front == rear )
        rear = NULL;
      a = front->data;
      front = front->next;
      delete temp;
      isGood = true;
    }
   temp = NULL;

   return isGood;
 }

template <typename T>
bool Queue<T>::empty()const
 {
cout << "in queue Empty" << endl;
   bool isEmpty = false;

   if( front == NULL && rear == NULL )
     isEmpty = true;

   return isEmpty;
 }

template <typename T>
bool Queue<T>::full()const
 {
cout << "In queue full" << endl;
   bool isFull = false;

   //should I include if it's above52 it's full???

   return isFull;
 }

template <typename T>
bool Queue<T>::clear()
 {
cout << "In queueu clear" << endl;
   bool isGood;

   return isGood;
 }

template <typename T>
bool Queue<T>::operator==(const Queue& a )const
 {
cout << "in == queue" << endl;
   bool isGood = true, repeat = false;
   QNode<T>* temp = front;
   QNode<T>* temp2 = a.front;

   if( temp->data == temp2->data )
     repeat = true;

   while( repeat )
    {
      if( temp->data != temp2->data )
        return false;

      temp = temp->next;
      temp2 = temp2->next;

      if( temp2 == NULL || temp == NULL )
        repeat = false;
    }

   if( temp != NULL && temp!= NULL )
     isGood = false;

   return isGood;
 }


template <typename T>
void Queue<T>::print()const
 {
cout << "in queue print" << endl;
   if( !empty() )
    {
      QNode<T>* temp = front;
      while( temp != NULL )
       {
         cout << temp->data;
         temp = temp->next;
       }
    }

 }


// stack stay implementation
template <typename T>
Stack<T>::Stack(int a )
 {
cout << "in stack constructor" << endl;
   data = new T[a];
   max = a;
   top = -1;
   actual = 0;
 }

template <typename T>
Stack<T>::Stack( const Stack& a )
 {
cout << "in stack copy const" << endl;
   data = new T[a.max];
   for( int i = 0; i < a.actual; i++ )
    {
      data[i] = a.data[i];
    }
   max = a.max;
   top = a.top;
   actual = a.actual;
 }

template <typename T>
Stack<T>::~Stack()
 {
cout << "in stack deconstructor" << endl;
   delete[]data;
   max = 0;
   top = -1;
   actual = 0;
   data = NULL;
 }

template <typename T>
Stack<T>& Stack<T>::operator=( const Stack& a )
 {
cout << "in = stack" << endl;
   for( int i = 0; i < a.actual; i++ )
    {
      data[i] = a.data[i];
    }
   max = a.max;
   top = a.top;
   actual = a.actual;
   
   return *this;
 }

template <typename T>
bool Stack<T>::push(T a)
 {
cout << "in stack push" << endl;
   bool isGood = false;
   int actCounter = actual;
cout << "actual " << actual << endl;
   if( full() == false )
    {
      for( int i = 0; i < actual; i++ )
       {
         data[actCounter]=data[actCounter-1];
         actCounter--;
       }

      if( top < 0 )
        top++;

      data[top] = a;

      actual++;

      isGood = true;
    }

   return isGood;
 }

template <typename T>
bool Stack<T>::pop( T& a ) 
 {
cout << "in stack pop" << endl;
   bool isGood = false;
   int topCounter=0;

   if( empty() == false )
    {
      a = data[top];

      for( int i = 0; i < actual-1; i++ )
       {
         data[topCounter] = data[topCounter+1];
         topCounter++;
       }
      actual--;

      if( actual == 0 )
       top--;

      isGood = true;
    }

   return isGood;
 }

template <typename T>
bool Stack<T>::empty() const
 {
cout << "in stack empty" << endl;
   bool isEmpty = false;

   if( actual == 0 )
     isEmpty = true;

   return isEmpty;
 }

template <typename T>
bool Stack<T>::full()const
 {
//cout << "in stack full" << endl;
   bool isFull = false;

   if( actual == max )
     isFull = true;

   return isFull;
 }

template <typename T>
bool Stack<T>::clear()  // why is this bool?
 {
cout << "in stack clear" << endl;
   bool isClear = false;

   if( top == -1 && actual == 0 )
     return isClear;

   top = -1;
   actual = 0;
   isClear = true;

   return isClear;
 }

template <typename T>
void Stack<T>::print()const
 {
cout << "in stack print" << endl;
   for( int i = 0; i < actual; i++ )
    {
     if( i == 0 )
      {
        cout << '[' << data[i] << ']' << endl;
      } 
     else
        cout << data[i] << endl;
    }
 }

// node based list implementation

// class node
ListNode::ListNode(card a, ListNode* nptr ) //DO I NEED TO HAVE A DECLARATION OF NEW MEM?
 {
cout << "in list node" << endl;
   data = a;
   next = nptr;
 }

//ostream& operator<<(ostream& output, const List& a );

// class List
List::List( int a )  
 {
cout << "in list constructor" << endl;
   head = NULL;  
   cursor = NULL;  
 }

List::List(const List& a ) // issue here with leaving an item out?
 {
   if( a.empty() )
    {
     head = NULL;
     cursor = NULL;
    }
   else
    {
cout << "in list copy const" << endl;
      ListNode* tempA = a.head;
      ListNode* tempNew;

      head = new ListNode( tempA->data, NULL );
      tempA = a.head->next;
      cursor = head;

      if( a.head->next != NULL )        // head node
       {
         cursor = new ListNode( tempA->data, NULL );
         head->next = cursor;
         tempNew = cursor;
         tempA = tempA->next;
       }

      while( tempA != NULL )//->next != NULL )
       {
         cursor = new ListNode( tempA->data, NULL );

         tempNew->next = cursor;
         tempNew = cursor;
         tempA = tempA->next;
       }
    }
 }

List::~List()
 {
cout << "in list deconst" << endl;
   if( head == NULL )
cout << "luke error found?" << endl;
//     delete head;

   else
    {
      while( head->next != NULL )
       {
         cursor = head->next;
         delete head;
         head = cursor;
       }
//      delete head;
    }
   cursor = head = NULL;
 }

bool List::gotoBeginning()
 {
cout << "in goto beginning" << endl;
   bool isGood = false;

   if( !empty() )
    {
      cursor = head;
      isGood = true;
    }

   return isGood;
 }

bool List::gotoEnd()
 {
cout << "in goto end" << endl;
   bool isGood = false;

   if( !empty() )
    {
      while( cursor->next != NULL )
       {
         cursor = cursor->next;
       }
      isGood = true;
    }
   return isGood;
 }

bool List::gotoNext()
 {
cout << "in go to next list" << endl;
   bool isGood = false;

   if( !empty() && cursor->next != NULL )
    {
      cursor = cursor->next;
      isGood = true;
    }

   return isGood;
 }

bool List::gotoPrior()
 {
cout << "in goto prior" << endl;
   bool isGood = false;
   ListNode* temp = head;

   if( !empty() && cursor->next != head->next )
    {
      while( temp->next != cursor )
       {
         temp = temp->next;
       }
      cursor = temp;
      isGood = true;
    }

   return isGood; 
 }

bool List::insertAfter( card a )
 {
cout << "in insert after" << endl;
   bool isGood = false;
   ListNode* temp;

   if( !full() )
    {
      if( head == NULL ) // if list empty
       {
         head = new ListNode( a, NULL );
         cursor = head;
       }

      else
       {
         if( cursor->next == NULL )
          {
            temp = new ListNode(a, NULL );
            cursor->next = temp;
            cursor = temp;
            temp = NULL;
          }

         else
          {
            temp = new ListNode( a, NULL );
            temp->next = cursor->next;
            cursor->next = temp;
            cursor = temp;
            temp = NULL;
          }
       }
      isGood = true;
    }

   return isGood;
 }

bool List::insertBefore( card a )
 {
cout << "in insert before " << endl;
   bool isGood = false;
   ListNode* temp;

   if( !empty() || !full() )
    {
      temp = new ListNode( cursor->data, cursor->next );
      cursor->next = temp;
      cursor->data = a;
      isGood = true;
      temp = NULL;
    }

   return isGood;
 }

bool List::remove(card& a )
 {
cout << "in remove cards" << endl;
   bool isGood = false;
   ListNode* temp;

   if( !empty() )
    {
      a = cursor->data;
      temp = cursor->next;
      if( temp != NULL )
       {
         cursor->data = temp->data; //ERROR IS HERE
         cursor->next = temp->next;
       }
      else
       {
         temp = cursor;
         if( temp == head )
          {
            cursor->next = NULL;
            head->next = NULL;
          }
         else
          {
            gotoPrior();
            cursor->next = NULL;
          }
       }
      delete temp;
      isGood = true;
    }

   return isGood;
 }

bool List::replace(card a )
 {
cout << "in replace card list" << endl;
   bool isGood = false;

   if( !empty() ) 
    {
      cursor->data = a;
      isGood = true;
    }

   return isGood;
 }

bool List::getCursor( card& a )const
 {
cout << "in get curosr" << endl;
   bool isGood = false;

   if( !empty() )
    {
      a = cursor->data;
      isGood = true;
    }

   return isGood;
 }

bool List::empty()const
 {
//cout << "in list empty" << endl;
   bool isEmpty = false;

   if( head == NULL )
    {
      isEmpty = true;
    }

   return isEmpty;
 }

bool List::full()const 
 {
cout << "in list full" << endl;
   bool isFull = false;

   return isFull;
 }

bool List::clear()
 {
cout << "in list clear" << endl;
   bool isClear = false;

   if( !empty() )
    { 
      while( head != NULL )
       {
         cursor = head;
         head = head->next;
         delete cursor;
       }
      cursor = head = NULL;
      isClear = true;
    }

   return isClear;
 }

List& List::operator=(const List& a)
 {
cout << "in = list" << endl;
   ListNode* temp = head;
   ListNode* temp2;
   ListNode* aTemp = a.head;

   while( aTemp != NULL )
    {
      if( empty() )
       {
         head = new ListNode( aTemp->data, NULL );
         temp = head;
         aTemp = aTemp->next;
       }

      else if( temp->next != NULL )
       {
         temp->data = aTemp->data;
         aTemp = aTemp->next;
         temp = temp->next;
       }

      else
       {
         temp2 = new ListNode( aTemp->data, NULL );
         temp->next = temp2;
         temp = temp->next;
         aTemp = aTemp->next;
       }

    }

   while( temp->next != NULL )
    {
      temp2 =temp; //= temp->next;
      temp = temp->next;
      delete temp2;
    }

   // set the cursor
   aTemp = a.head;
   cursor = head;

   while( aTemp != a.cursor )
    {
      aTemp = aTemp->next;
      cursor = cursor->next; 
    }

   return *this;
 }

ostream& operator<<(ostream& output, const List& a )
 {
cout << "in << list" << endl;
   ListNode* temp = a.head;
   output << "[] indidcates cursor" << endl;

   while( temp != NULL )
    {
      if( temp == a.cursor )
       {
         output << '[' << temp->data << ']';
         temp = temp->next;
       }

      else
       {
         output << temp->data;
         temp = temp->next;
       }
    }
   return output;
 }

bool List::operator==(const List& a )const
 {
cout << " in == list" << endl;
   bool isGood = true, repeat = false;
   ListNode* aTemp = a.head;
   ListNode* temp = head;

   if( aTemp->data == temp->data )
       repeat = true;

   while( repeat )
    {
      if( !(aTemp->data == temp->data) )
         return false;

      aTemp = aTemp->next;
      temp = temp->next;

      if( aTemp == NULL || temp == NULL )
         repeat = false;
    }
   if( aTemp != NULL && temp != NULL ) 
     isGood = false;

   return isGood;
 }
