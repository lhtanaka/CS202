#ifndef __DATASTRUCT_H_
#define __DATASTRUCT_H_
#include <iostream>



using namespace std;

// card class
class card{
    public:
	card();
	card( int, string, string );
	card( const card & );
	~card();
	void setLoc( const string );
	int getRank()const;
	string getSuit()const;
	string getLoc()const;
	bool operator<(const card& );
	card& operator=(const card& );
	bool operator==(const card& );
	friend bool operator>(const card&, const card& );
	friend ostream& operator<<(ostream&, const card& );
	friend ifstream& operator>>(ifstream&, card& );
    private:
	int rank;
	string suit;
	string location;
    };

//player class
template <typename T>
class Stack;

//template <typename T>
class player{
    public:
	player();
	player( const player& );
	~player();
	void setId( const int* );
	void setHand( Stack<card>&, const int, const int );
	string getName()const;
	int* getId()const;
	card* getHand()const;
        player& operator=(const player& );
        bool operator==(const player& );
	friend ostream& operator<<(ostream&, const player& );
	friend ifstream& operator>>(ifstream&, player& );
//        friend class Stack<T>;
    private:
	string name;
	int* id;
	card* hand;
    };


template <typename T>
class Queue;

template <typename T>
class QNode{
	private:
		QNode( T, QNode* = NULL );
		T data;
		QNode* next;
		friend class Queue<T>;
          };

template <typename T>
class Queue{
        public:
                Queue(int = 0);
                Queue(const Queue&);
                ~Queue();
                Queue& operator=(const Queue&);
                bool enqueue(T);
                bool dequeue(T&);
                bool empty() const;
                bool full() const;
                bool clear();
                bool operator==(const Queue&) const;
		void print()const;

        private:
                QNode<T>* front;
                QNode<T>* rear;
};


class List;

class ListNode{
	private:
		ListNode(card, ListNode* = NULL);
		card data;
		ListNode* next;
		friend class List;
                friend ostream& operator<<(ostream&, const List&);
};

class List{
        public:
                List(int = 0);
                List(const List&);
                ~List();
		bool gotoBeginning();
		bool gotoEnd();
		bool gotoNext();
                bool gotoPrior();
		bool insertAfter(card);
		bool insertBefore(card);
                bool remove(card&);
		bool replace(card);
		bool getCursor(card&) const;
                bool empty() const;
                bool full() const;
                bool clear();
		List& operator=(const List&);
                friend ostream& operator<<(ostream&, const List&);
                bool operator==(const List&) const;
        private:
		ListNode* head;
		ListNode* cursor;
};

template <typename T>
class Stack {
        public:
                Stack(int = 52);
                Stack(const Stack&);
                ~Stack();
                Stack<T>& operator=(const Stack&);
                bool push(T);
                bool pop(T&);
                bool empty() const;
                bool full() const;
                bool clear();
                void print() const;
        private:
                int max;
                int top;
                int actual; //only used in stack (stay) implementation
                T* data;
};




#endif
